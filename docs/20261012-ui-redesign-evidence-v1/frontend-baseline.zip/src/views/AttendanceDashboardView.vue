<template>
  <div class="space-y-6">
    <!-- 顶部状态栏与课堂排课关联选择器 -->
    <div class="pro-card p-6 bg-gradient-to-r from-white via-slate-50/60 to-indigo-50/20 border border-slate-200/80 shadow-card-hover rounded-2xl flex flex-wrap items-center justify-between gap-5">
      <div class="flex items-center gap-4">
        <div class="w-13 h-13 rounded-2xl bg-gradient-to-br from-indigo-500 to-navy-700 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 ring-4 ring-indigo-50">
          <Video class="w-6 h-6" />
        </div>
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2.5">
              课堂智能考勤与态势监控大屏
              <span v-if="isMonitoring" class="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/80 font-semibold shadow-2xs">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                {{ monitorReporting ? "摄像头与考勤数据已连接" : "摄像头画面已就绪，正在连接数据" }}
              </span>
              <span v-else class="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-slate-100 text-slate-600 border border-slate-200 font-semibold">
                <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                待机就绪
              </span>
            </h1>
          </div>
          <p class="text-xs text-slate-500 mt-1 font-sans">
            按所选班次名单识别出勤，实时查看课堂在座与抬头状态。
          </p>
        </div>
      </div>

      <!-- 关联当前开课与班级 -->
      <div class="flex flex-wrap items-center gap-2.5">
        <div class="flex items-center gap-2 bg-white/90 px-3.5 py-1.5 rounded-xl border border-slate-200/80 text-xs text-slate-600 shadow-2xs">
          <span class="font-bold text-slate-700 whitespace-nowrap">当前授课班级：</span>
          <select 
            v-if="activeOfferingList.length > 0"
            v-model.number="selectedOfferingId" 
            @change="onOfferingChange" 
            :disabled="isMonitorStarting || isSimulationStarting"
            class="bg-white border border-slate-300 text-slate-800 font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 cursor-pointer rounded-lg px-2.5 py-1 text-xs shadow-2xs min-w-[280px] max-w-md"
          >
            <option 
              v-for="off in activeOfferingList" 
              :key="off.id" 
              :value="Number(off.id)"
              class="bg-white text-slate-800 py-1.5 font-medium"
            >
              【{{ off.className }}】{{ off.course?.courseName || '课程' }} - {{ off.teacherName }} ({{ off.studentCount }}人){{ off.isSnapshotFrozen ? " · 已冻结，只读" : "" }}
            </option>
          </select>
          <select 
            v-else 
            disabled 
            class="bg-slate-100 border border-slate-200 text-slate-400 font-semibold rounded-lg px-2.5 py-1 text-xs shadow-xs min-w-[80px] cursor-not-allowed text-center"
          >
            <option selected value="">无</option>
          </select>
        </div>

        <!-- 授课时段徽章状态 -->
        <div
          class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs border font-semibold shadow-2xs"
          :class="currentOfferingSessionStatus.inSession ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-amber-50 text-amber-800 border-amber-200'"
        >
          <span class="w-2 h-2 rounded-full" :class="currentOfferingSessionStatus.inSession ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'"></span>
          <span>{{ currentOfferingSessionStatus.inSession ? '正在授课时段中' : '非当前授课时段' }}</span>
          <span class="text-[11px] text-slate-500 font-mono">({{ currentOfferingSessionStatus.periodText }})</span>
        </div>

        <!-- 班级花名册与选人入班按钮 -->
        <button
          @click="openClassStudentModal"
          :disabled="!selectedOfferingId"
          :class="[
            'px-3.5 py-2 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition shadow-2xs',
            selectedOfferingId
              ? 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 cursor-pointer'
              : 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed opacity-60'
          ]"
          :title="canManageRoster ? '查看和维护班级学生名单' : '查看本班已选学生'"
        >
          <Users class="w-3.5 h-3.5 text-slate-500" />
          {{ canManageRoster ? "班级成员选拔" : "班级学生名单" }} ({{ overview.totalRegistered }}人)
        </button>

        <!-- 核心按钮：启动/停止摄像头智能考勤 -->
        <button
          @click="toggleMonitor"
          :disabled="!canWriteAttendance || isMonitorStarting || isSimulationStarting || isSimulating"
          :class="[
            'px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition shadow-xs',
            !canWriteAttendance
              ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed opacity-60'
              : isMonitoring
              ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 cursor-pointer'
              : 'bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white cursor-pointer shadow-indigo-500/20'
          ]"
          :title="!canWriteAttendance ? '请选择未冻结的授课班级' : ''"
        >
          <span v-if="isMonitorStarting" class="w-3.5 h-3.5 rounded-full border-2 border-current border-t-transparent animate-spin"></span>
          <Square v-else-if="isMonitoring" class="w-3.5 h-3.5" />
          <Camera v-else class="w-3.5 h-3.5" />
          {{ isMonitorStarting ? '正在拉起推断引擎...' : isMonitoring ? '停止摄像头监控' : '打开摄像头开启考勤' }}
        </button>

        <!-- 一键下课归档考勤结果 -->
        <button
          @click="finishAndArchiveAttendance"
          :disabled="!canWriteAttendance || isMonitorStarting || isSimulationStarting || (!currentSessionId && !isSimulating && !isMonitoring && overview.currentPresent === 0 && lastActiveMetrics.present === 0)"
          :class="[
            'px-4 py-2 rounded-xl text-xs font-semibold shadow-xs transition flex items-center gap-1.5',
            canWriteAttendance && (currentSessionId || isSimulating || isMonitoring || overview.currentPresent > 0 || lastActiveMetrics.present > 0)
              ? 'bg-navy-900 hover:bg-navy-800 text-white cursor-pointer shadow-navy-900/20'
              : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed opacity-60'
          ]"
          title="将当前课堂考勤与抬头率数据永久归档入库并下课"
        >
          <Archive class="w-3.5 h-3.5" />
          结束考勤并归档下课
        </button>

        <!-- 备用按钮：模拟推流 -->
        <button
          @click="toggleSimulation"
          :disabled="!canWriteAttendance || isMonitoring || isMonitorStarting || isSimulationStarting"
          :class="[
            'px-3.5 py-2 rounded-xl text-xs font-semibold transition border shadow-2xs',
            !canWriteAttendance
              ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed opacity-60'
              : isSimulating
              ? 'bg-amber-50 text-amber-800 border-amber-200 cursor-pointer'
              : 'bg-white hover:bg-slate-50 text-slate-600 border-slate-200 cursor-pointer'
          ]"
          :title="!canWriteAttendance ? '请选择未冻结的授课班级' : ''"
        >
          {{ isSimulationStarting ? '正在启动模拟...' : isSimulating ? '暂停模拟' : '演示模拟流' }}
        </button>

        <!-- 查看已归档考勤历史明细 -->
        <button
          @click="openArchiveModal"
          :disabled="!selectedOfferingId"
          :class="[
            'px-3.5 py-2 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition shadow-2xs',
            selectedOfferingId
              ? 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 cursor-pointer'
              : 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed opacity-60'
          ]"
          title="查看本课程在 MySQL 中持久化的历次考勤归档记录"
        >
          <Clock class="w-3.5 h-3.5 text-indigo-600" />
          考勤归档记录 ({{ archivedSessions.filter(s => s.status === 'FINISHED').length }}次)
        </button>
      </div>
    </div>

    <!-- 1. 核心大盘指标卡片 (严格区隔本班出勤率与非本班旁听学生) -->
    <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
      <MetricCard
        title="实到人数 (本班)"
        :value="overview.currentPresent"
        unit="人"
        :subtitle="`出勤率 ${overview.attendanceRate}%`"
        variant="blue"
      />
      <MetricCard
        title="应到总数 (本班)"
        :value="overview.totalRegistered"
        unit="人"
        subtitle="当前排课班额"
        variant="cyan"
      />
      <MetricCard
        title="非本班听课"
        :value="overview.auditingCount ?? 0"
        unit="人"
        subtitle="旁听不计入班级出勤率"
        variant="purple"
      />
      <MetricCard
        title="实时抬头率"
        :value="overview.realtimeLookupRate"
        unit="%"
        :subtitle="overview.focusLevel"
        variant="green"
      />
      <MetricCard
        title="低头走神"
        :value="overview.lookdownCount"
        unit="人"
        subtitle="Pitch 姿态 < -10°"
        :variant="overview.lookdownCount > 0 ? 'danger' : 'green'"
      />
      <MetricCard
        title="未到/缺勤"
        :value="overview.currentAbsent"
        unit="人"
        subtitle="本班缺席学生"
        variant="warning"
      />
      <MetricCard
        title="专注度评级"
        :value="overview.focusLevel.split(' ')[0]"
        subtitle="基于时序加权评估"
        variant="cyan"
      />
    </div>

    <!-- 2. 画中画视频感知视窗 + ECharts 抬头率与注意力流动波形图 -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <!-- 左侧：实时摄像头 AI 感知推断视窗 (占 5 列) -->
      <div class="lg:col-span-5 pro-card p-5 flex flex-col justify-between h-[390px] relative overflow-hidden">
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center gap-2">
            <div class="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Video class="w-3.5 h-3.5" />
            </div>
            <h3 class="text-xs font-bold text-slate-900 tracking-wide">摄像头实时人脸考勤与姿态 HUD 视窗</h3>
          </div>
          <span v-if="isMonitoring" class="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono font-bold shadow-2xs">
            LIVE 1:N 识别
          </span>
          <span v-else class="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200 font-medium">
            待命中
          </span>
        </div>

        <!-- 监控开启时的实时画面 (MJPEG 流) -->
        <div class="flex-1 w-full bg-slate-950 rounded-xl overflow-hidden relative flex items-center justify-center border border-slate-900 shadow-inner">
          <img
            v-if="isMonitoring"
            :src="videoFeedUrl"
            alt="AI 视觉感知推断流"
            class="w-full h-full object-cover rounded-xl"
            @error="onVideoFeedError"
          />

          <!-- 未开启摄像头时的待机面板 -->
          <div v-else class="flex flex-col items-center justify-center text-center p-6 space-y-3">
            <div class="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 shadow-inner ring-4 ring-slate-900/50">
              <Camera class="w-7 h-7 text-slate-400" />
            </div>
            <div>
              <p class="text-xs font-bold text-slate-200">
                {{ selectedOfferingId ? '摄像头考勤感知视窗处于就绪状态' : (currentUser?.role === 'TEACHER' ? '您当前暂无处于授课时段的个人课程' : '当前暂无处于授课时段的班级') }}
              </p>
              <p class="text-[11px] text-slate-400 mt-1.5 max-w-xs leading-relaxed">
                {{ selectedOfferingId ? '点击上方【打开摄像头开启考勤】唤起 InsightFace 识别引擎，现场画中画实时渲染人脸框与 3D 姿态角' : (currentUser?.role === 'TEACHER' ? '任课教师仅可在本人授课时段开展随堂考勤与态势监控。若未到授课时间，请前往任课教师工作台备课或查看课表排期。' : '教务排课时间校验生效中，系统仅限处于有效授课时段的课程方可开展随堂视觉考勤。') }}
              </p>
            </div>
          </div>
        </div>

        <!-- 底部推断参数条 -->
        <div class="flex items-center justify-between mt-2.5 pt-2.5 border-t border-slate-100 text-[10px] text-slate-500 font-mono">
          <span>{{ isMonitoring ? '实时摄像头画面' : '摄像头未启动' }}</span>
          <span class="text-indigo-600 font-bold">识别结果按当前班次同步</span>
        </div>
      </div>

      <!-- 右侧：抬头率与在座人数时序折线图 (占 7 列) -->
      <div class="lg:col-span-7 pro-card p-5 flex flex-col justify-between h-[390px]">
        <div class="flex items-center justify-between mb-2 pb-2 border-b border-slate-100">
          <div class="flex items-center gap-2">
            <div class="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <TrendingUp class="w-3.5 h-3.5" />
            </div>
            <h3 class="text-xs font-bold text-slate-900 tracking-wide">课堂抬头率与出勤人数时序波形 (LookUp Trend)</h3>
          </div>
          <span class="text-[10px] text-slate-400 font-mono">每 1.2 秒平滑流动更新</span>
        </div>
        <div class="flex-1 w-full min-h-[300px]">
          <FocusTrendChart :data="trendData" />
        </div>
      </div>
    </div>

    <div v-if="monitorError" role="alert" data-testid="monitor-error" class="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
      {{ monitorError }}。请检查登录与班次状态后重新启动摄像头。
    </div>

    <!-- 3. 学生实时在座考勤与姿态网格卡片 -->
    <StudentStatusGrid :students="studentsStatus" />

    <!-- 弹窗：开课班级学生管理与从总库选人入班 -->
    <div v-if="showStudentModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div class="bg-white border border-slate-200 rounded-2xl w-full max-w-3xl p-6 shadow-modal space-y-4 max-h-[85vh] flex flex-col">
        <!-- 弹窗头部 -->
        <div class="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
              <Users class="w-5 h-5 text-indigo-600" />
              {{ canManageRoster ? "班级学生花名册与选拔管理" : "班级学生花名册" }}
              <span class="text-xs px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-semibold">
                {{ offeringList.find(o => o.id === selectedOfferingId)?.className }}
              </span>
            </h3>
            <p class="text-xs text-slate-500 mt-1">
              {{ canManageRoster ? "选择学生加入本班，或将学生移出本班。" : "查看本班已选学生；名单由教研室主任维护。" }}
            </p>
          </div>
          <button @click="showStudentModal = false" class="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition cursor-pointer">
            <X class="w-5 h-5" />
          </button>
        </div>

        <!-- 标签切换 -->
        <div class="flex items-center gap-2 border-b border-slate-200 pb-2 text-xs">
          <button
            @click="activeModalTab = 'enrolled'"
            :class="['px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer', activeModalTab === 'enrolled' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200 shadow-2xs' : 'text-slate-500 hover:text-slate-800']"
          >
            <span>本班已有学生名单 ({{ currentOfferingStudents.length }}人)</span>
          </button>
          <button
            v-if="canManageRoster"
            @click="activeModalTab = 'add'"
            :class="['px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer', activeModalTab === 'add' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200 shadow-2xs' : 'text-slate-500 hover:text-slate-800']"
          >
            <UserPlus class="w-3.5 h-3.5" />
            <span>从总档案库选入学生 (可选 {{ availableStudents.length }}人)</span>
          </button>
        </div>

        <!-- 内容区域 1: 当前班级学生列表 -->
        <div v-if="activeModalTab === 'enrolled'" class="flex-1 overflow-y-auto space-y-2.5 pr-1">
          <div v-if="currentOfferingStudents.length === 0" class="py-14 text-center text-slate-400 text-xs bg-slate-50 rounded-xl">
            {{ canManageRoster ? "当前班级暂无学生，可从总档案库选入学生。" : "当前班级暂无已选学生。" }}
          </div>
          <div
            v-for="s in currentOfferingStudents"
            :key="s.studentId"
            class="flex items-center justify-between p-3 bg-white border border-slate-200/80 rounded-xl hover:border-indigo-300 transition shadow-2xs"
          >
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs overflow-hidden shadow-2xs">
                <img v-if="s.avatarUrl" :src="s.avatarUrl" class="w-full h-full object-cover" />
                <span v-else>{{ s.name?.charAt(0) }}</span>
              </div>
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-xs font-bold text-slate-900">{{ s.name }}</span>
                  <span class="text-[10px] text-slate-500">({{ s.gender || '未知' }})</span>
                </div>
                <span class="text-[11px] font-mono text-indigo-600 font-semibold">{{ s.studentId }}</span>
              </div>
            </div>

            <button
              v-if="canManageRoster"
              @click="handleRemoveStudentFromClass(s.studentId, s.name)"
              class="px-3 py-1.5 text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition font-semibold cursor-pointer"
            >
              移出班级
            </button>
          </div>
        </div>

        <!-- 内容区域 2: 从总库选入学生 -->
        <div v-if="canManageRoster && activeModalTab === 'add'" class="flex-1 overflow-y-auto space-y-2.5 pr-1">
          <div v-if="availableStudents.length === 0" class="py-14 text-center text-slate-400 text-xs bg-slate-50 rounded-xl">
            总档案库中暂无其他待分配或属于其他班级的候选学生
          </div>
          <div
            v-for="s in availableStudents"
            :key="s.studentId"
            class="flex items-center justify-between p-3 bg-white border border-slate-200/80 rounded-xl hover:border-slate-300 transition shadow-2xs"
          >
            <div class="flex items-center gap-3">
              <input
                type="checkbox"
                :value="s.studentId"
                v-model="selectedStudentsToAdd"
                class="rounded border-slate-300 text-indigo-600 focus:ring-0 cursor-pointer w-4 h-4"
              />
              <div class="w-9 h-9 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs overflow-hidden shadow-2xs">
                <img v-if="s.avatarUrl" :src="s.avatarUrl" class="w-full h-full object-cover" />
                <span v-else>{{ s.name?.charAt(0) }}</span>
              </div>
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-xs font-bold text-slate-900">{{ s.name }}</span>
                  <span class="text-[10px] text-slate-500">({{ s.gender || '未知' }})</span>
                  <span class="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                    当前: {{ s.className || '未分配' }}
                  </span>
                </div>
                <span class="text-[11px] font-mono text-indigo-600 font-semibold">{{ s.studentId }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 底部操作栏 -->
        <div class="flex items-center justify-between border-t border-slate-100 pt-3 text-xs">
          <span class="text-slate-500">
            班级当前人数：<b class="text-slate-900 font-bold">{{ currentOfferingStudents.length }}</b> 人
          </span>
          <div class="flex items-center gap-2.5">
            <button
              v-if="canManageRoster && activeModalTab === 'add'"
              @click="handleAddStudentsToClass"
              :disabled="selectedStudentsToAdd.length === 0"
              :class="['px-4 py-2 rounded-xl font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer', selectedStudentsToAdd.length > 0 ? 'bg-indigo-600 hover:bg-indigo-700 text-white' : 'bg-slate-100 text-slate-400 cursor-not-allowed']"
            >
              <Check class="w-3.5 h-3.5" />
              确认选入选中的 {{ selectedStudentsToAdd.length }} 人
            </button>
            <button @click="showStudentModal = false" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl transition cursor-pointer">
              完成 / 关闭
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- 弹窗：历史考勤归档记录 (MySQL 持久化档案库) -->
    <div v-if="showArchiveModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div class="bg-white border border-slate-200 rounded-2xl w-full max-w-6xl p-6 shadow-modal space-y-4 max-h-[88vh] flex flex-col">
        <!-- 弹窗头部 -->
        <div class="flex items-center justify-between border-b border-slate-100 pb-3">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shadow-2xs">
              <Archive class="w-5 h-5" />
            </div>
            <div>
              <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                课程考勤历史归档记录 (MySQL 档案库)
                <span class="text-xs px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono font-bold">
                  已归档 {{ archivedSessions.filter(s => s.status === 'FINISHED').length }} 次
                </span>
              </h3>
              <p class="text-xs text-slate-500 mt-1">
                班级：{{ offeringList.find(o => o.id === selectedOfferingId)?.className }} · 课程：{{ offeringList.find(o => o.id === selectedOfferingId)?.course?.courseName }} (主讲：{{ offeringList.find(o => o.id === selectedOfferingId)?.teacherName }})
              </p>
            </div>
          </div>
          <button @click="showArchiveModal = false" class="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition cursor-pointer">
            <X class="w-5 h-5" />
          </button>
        </div>

        <!-- 归档记录表格 -->
        <div class="flex-1 overflow-x-auto overflow-y-auto border border-slate-200/80 rounded-xl shadow-inner">
          <div v-if="isLoadingArchive" class="py-16 text-center text-slate-400 text-xs flex items-center justify-center gap-2">
            <span class="w-4 h-4 rounded-full border-2 border-indigo-600 border-t-transparent animate-spin"></span>
            正在查询数据库归档记录...
          </div>
          <div v-else-if="archivedSessions.length === 0" class="py-16 text-center text-slate-400 text-xs">
            当前课程班级暂无历史考勤归档记录，开展摄像头考勤或演示模拟流并点击【结束考勤并归档下课】后即可在此查验入库数据。
          </div>
          <table v-else class="w-full text-left text-xs text-slate-700 min-w-[960px] border-collapse">
            <thead class="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200 sticky top-0 z-10">
              <tr>
                <th class="py-3.5 px-3.5 text-center whitespace-nowrap">会话ID</th>
                <th class="py-3.5 px-3.5 text-center whitespace-nowrap">教学周次</th>
                <th class="py-3.5 px-3.5 text-left whitespace-nowrap">授课教室</th>
                <th class="py-3.5 px-3.5 text-left whitespace-nowrap">考勤起止时间</th>
                <th class="py-3.5 px-3.5 text-center whitespace-nowrap">应到人数</th>
                <th class="py-3.5 px-3.5 text-center whitespace-nowrap">实到人数</th>
                <th class="py-3.5 px-3.5 text-center whitespace-nowrap">出勤率</th>
                <th class="py-3.5 px-3.5 text-center whitespace-nowrap">平均抬头率</th>
                <th class="py-3.5 px-3.5 text-left whitespace-nowrap">考勤人员</th>
                <th class="py-3.5 px-3.5 text-center whitespace-nowrap">状态</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 bg-white">
              <tr v-for="s in archivedSessions" :key="s.id" class="hover:bg-slate-50 transition">
                <td class="py-3.5 px-3.5 text-center font-mono font-bold text-indigo-600 whitespace-nowrap">#{{ s.id }}</td>
                <td class="py-3.5 px-3.5 text-center whitespace-nowrap font-medium text-slate-700">第 {{ s.weekNumber || 2 }} 周</td>
                <td class="py-3.5 px-3.5 text-left whitespace-nowrap text-slate-800 font-semibold">{{ s.classroom || getCurrentClassroom() }}</td>
                <td class="py-3.5 px-3.5 text-left whitespace-nowrap font-mono text-[11px] text-slate-600">
                  <div class="flex items-center gap-1.5 whitespace-nowrap">
                    <span>{{ s.startTime ? s.startTime.replace('T', ' ').substring(0, 16) : '--' }}</span>
                    <span class="text-slate-400">至</span>
                    <span>{{ s.endTime ? s.endTime.replace('T', ' ').substring(0, 16) : '进行中' }}</span>
                  </div>
                </td>
                <td class="py-3.5 px-3.5 text-center font-mono text-slate-600 whitespace-nowrap">{{ s.expectedCount }} 人</td>
                <td class="py-3.5 px-3.5 text-center font-mono font-bold text-slate-900 whitespace-nowrap">{{ s.actualCount }} 人</td>
                <td class="py-3.5 px-3.5 text-center whitespace-nowrap">
                  <span 
                    :class="[
                      'inline-flex items-center justify-center min-w-[54px] px-2 py-0.5 rounded-full text-[11px] font-bold font-mono shadow-2xs',
                      s.attendanceRate >= 80 
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                        : s.attendanceRate > 0 
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    ]"
                  >
                    {{ s.attendanceRate }}%
                  </span>
                </td>
                <td class="py-3.5 px-3.5 text-center font-mono text-indigo-700 font-bold text-xs whitespace-nowrap">{{ s.avgLookupRate }}%</td>
                <td class="py-3.5 px-3.5 text-left whitespace-nowrap">
                  <span 
                    :class="[
                      'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold border shadow-2xs whitespace-nowrap',
                      s.operatorRole === 'DIRECTOR'
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : s.operatorRole === 'SUPERVISOR'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-indigo-50 text-indigo-800 border-indigo-200'
                    ]"
                  >
                    <ShieldCheck v-if="s.operatorRole === 'SUPERVISOR'" class="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <Briefcase v-else-if="s.operatorRole === 'DIRECTOR'" class="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <UserCheck v-else class="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>{{ formatOperatorDisplay(s) }}</span>
                  </span>
                </td>
                <td class="py-3.5 px-3.5 text-center whitespace-nowrap">
                  <span 
                    :class="[
                      'inline-flex items-center justify-center min-w-[64px] px-2.5 py-1 rounded-md text-xs font-semibold whitespace-nowrap shadow-2xs',
                      s.status === 'FINISHED' 
                        ? 'bg-slate-100 text-slate-700 border border-slate-200' 
                        : 'bg-emerald-50 text-emerald-700 border border-emerald-200 animate-pulse'
                    ]"
                  >
                    {{ s.status === 'FINISHED' ? '已归档' : '授课中' }}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 弹窗底部说明 -->
        <div class="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span class="text-[11px] text-slate-400">
            * 无论通过现场摄像头 AI 识别还是演示模拟流，每次下课归档均原子性写入 MySQL `attendance_session` 数据库，数据真实可信。
          </span>
          <button @click="showArchiveModal = false" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl transition cursor-pointer">
            关闭
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { Video, Users, Camera, Archive, Square, TrendingUp, X, UserPlus, Check, Clock, ShieldCheck, Briefcase, UserCheck } from 'lucide-vue-next'
import MetricCard from '../components/MetricCard.vue'
import FocusTrendChart from '../components/FocusTrendChart.vue'
import StudentStatusGrid from '../components/StudentStatusGrid.vue'
import { visualApi, courseApi, attendanceApi, scheduleApi, authApi } from '../api'
import type { DashboardOverviewVO, FocusTrendPointVO, StudentRealtimeStatusVO, CourseOffering, CourseSchedule } from '../api/types'
import { isScheduleInSession } from '../utils/scheduleTime'
import { attendanceMetrics, lookupRatio } from '../api/metrics.mjs'

const props = defineProps<{
  initialOfferingId?: number | null
  loggedInUser?: any
}>()

const internalUser = ref<any>(props.loggedInUser || null)
const currentUser = computed(() => props.loggedInUser || internalUser.value)

const overview = ref<DashboardOverviewVO>({
  totalRegistered: 0,
  currentPresent: 0,
  currentAbsent: 0,
  attendanceRate: 0,
  realtimeLookupRate: 0,
  lookdownCount: 0,
  focusLevel: '待启动',
  auditingCount: 0,
  auditingStudentIds: [],
  lastUpdateTime: ''
})

const trendData = ref<FocusTrendPointVO[]>([])
const studentsStatus = ref<StudentRealtimeStatusVO[]>([])

const offeringList = ref<CourseOffering[]>([])
const scheduleList = ref<CourseSchedule[]>([])
const selectedOfferingId = ref<number | null>(null)
const currentSessionId = ref<number | null>(null)

const isMonitoring = ref(false)
const isMonitorStarting = ref(false)
const monitorError = ref('')
const monitorReporting = ref(false)
let monitorAbort: AbortController | null = null
let monitorGeneration = 0
let cameraSessionId: number | null = null
const stopCamera = async () => {
  monitorGeneration++
  monitorAbort?.abort()
  monitorAbort = null
  const owned = isMonitoring.value || isMonitorStarting.value
  isMonitoring.value = false; isMonitorStarting.value = false; monitorReporting.value = false
  if (owned) await visualApi.stopMonitor()
}
const isSimulating = ref(false)
const isSimulationStarting = ref(false)
let simulationGeneration = 0
let dashboardActive = true
const stopSimulation = () => {
  simulationGeneration++
  if (simulationTimer) clearInterval(simulationTimer)
  simulationTimer = null
  isSimulating.value = false
  isSimulationStarting.value = false
}
const videoFeedUrl = ref('/api/visual/video-feed')

let pollTimer: number | null = null
let simulationTimer: number | null = null

const showStudentModal = ref(false)
const currentOfferingStudents = ref<any[]>([])
const availableStudents = ref<any[]>([])
const selectedStudentsToAdd = ref<string[]>([])
const activeModalTab = ref<'enrolled' | 'add'>('enrolled')

// 考勤历史归档记录 (MySQL 持久化)
const archivedSessions = ref<any[]>([])
const showArchiveModal = ref(false)
const isLoadingArchive = ref(false)

// 锁存本次推流中检测到的最新有效考勤指标（防止下课停止推流时被清零冲刷）
const lastActiveMetrics = ref({
  present: 0,
  rate: 0,
  lookupRate: 0
})

// 格式化展示考勤人员身份
const formatOperatorDisplay = (s: any) => {
  if (s.operatorTitle && s.operatorName) {
    return `${s.operatorTitle} (${s.operatorName})`
  }
  if (s.operatorTitle) return s.operatorTitle
  if (s.operatorRole === 'SUPERVISOR') return `教学督导 (${s.operatorName || '督导专家'})`
  if (s.operatorRole === 'DIRECTOR') return `教研室主任 (${s.operatorName || '教研室主任'})`
  return `任课教师 (${s.operatorName || s.offering?.teacherName || '郭军'})`
}

const loadArchivedSessions = async () => {
  const offeringId = selectedOfferingId.value
  if (!offeringId) {
    archivedSessions.value = []
    return
  }
  try {
    isLoadingArchive.value = true
    const list = await attendanceApi.getByOffering(offeringId)
    if (selectedOfferingId.value === offeringId) archivedSessions.value = Array.isArray(list) ? list : []
  } catch (e) {
    console.error('加载历史考勤归档失败', e)
  } finally {
    if (selectedOfferingId.value === offeringId) isLoadingArchive.value = false
  }
}

const openArchiveModal = async () => {
  if (!selectedOfferingId.value) return
  await loadArchivedSessions()
  showArchiveModal.value = true
}

// 获取当前授课班级对应的真实排课教室 (优先当前在授时段，次选基础排课教室，如文管 A447)
const getCurrentClassroom = () => {
  if (!selectedOfferingId.value) return '文管 A447'
  const schedules = scheduleList.value.filter(s => s.offering?.id === selectedOfferingId.value)
  if (schedules.length === 0) return '文管 A447'
  const active = schedules.find(s => isScheduleInSession(s).inSession)
  if (active?.classroom) return active.classroom
  return schedules[0]?.classroom || '文管 A447'
}

// 加载排课课表
const loadSchedules = async () => {
  try {
    const list = await scheduleApi.getAll()
    scheduleList.value = Array.isArray(list) ? list : []
  } catch (e) {
    console.warn('获取排课日程失败', e)
  }
}

// 判断某个 offeringId 在当前真实时间是否处于授课时段中
const isOfferingInSession = (offeringId: number) => {
  const schedules = scheduleList.value.filter(s => s.offering?.id === offeringId)
  if (schedules.length === 0) return false
  return schedules.some(s => isScheduleInSession(s).inSession)
}

// The API already scopes primary/collaborating assignments by stable identity.
const activeOfferingList = computed(() => offeringList.value)
const selectedOffering = computed(() => offeringList.value.find(o => o.id === selectedOfferingId.value))
const canWriteAttendance = computed(() => !!selectedOffering.value && !selectedOffering.value.isSnapshotFrozen && selectedOffering.value.status !== 'FINISHED')
const canManageRoster = computed(() => currentUser.value?.role === 'DIRECTOR' && canWriteAttendance.value)

// 当前选中班级的授课时段状态
const currentOfferingSessionStatus = computed(() => {
  if (!selectedOfferingId.value) {
    return { inSession: false, periodText: '未选择班级' }
  }
  const schedules = scheduleList.value.filter(s => s.offering?.id === selectedOfferingId.value)
  if (schedules.length === 0) {
    return { inSession: false, periodText: '未排课' }
  }
  const active = schedules.find(s => isScheduleInSession(s).inSession)
  const weekNames = ['', '周一', '周二', '周三', '周四', '周五', '周六', '周日']
  if (active) {
    return {
      inSession: true,
      periodText: `${weekNames[active.dayOfWeek] || '周' + active.dayOfWeek} 第${active.startPeriod}-${active.endPeriod}节 (${active.classroom})`
    }
  }
  const first = schedules[0]
  return {
    inSession: false,
    periodText: `${weekNames[first.dayOfWeek] || '周' + first.dayOfWeek} 第${first.startPeriod}-${first.endPeriod}节 (${first.classroom})`
  }
})

// 同步初始所选开课班级
const syncSelectedOffering = () => {
  if (props.initialOfferingId && offeringList.value.some(o => o.id === Number(props.initialOfferingId))) {
    selectedOfferingId.value = Number(props.initialOfferingId)
    return
  }
  const validList = activeOfferingList.value
  if (validList.length > 0) {
    const currentInSession = validList.find(o => isOfferingInSession(o.id))
    selectedOfferingId.value = currentInSession ? currentInSession.id : validList[0].id
  } else {
    selectedOfferingId.value = null
  }
}

const loadOfferings = async () => {
  try {
    const list = await courseApi.getOfferings()
    offeringList.value = Array.isArray(list) ? list : []
  } catch (e) {
    console.error('获取授课班级失败', e)
  }
}

const onOfferingChange = async () => {
  const offeringId = selectedOfferingId.value
  stopSimulation()
  showStudentModal.value = false
  currentSessionId.value = null
  archivedSessions.value = []
  isLoadingArchive.value = false
  if (isMonitoring.value || isMonitorStarting.value) await stopCamera()
  monitorError.value = ''
  if (isSimulating.value && simulationTimer) {
    clearInterval(simulationTimer)
    simulationTimer = null
    isSimulating.value = false
  }
  if (selectedOfferingId.value !== offeringId) return
  lastActiveMetrics.value = { present: 0, rate: 0, lookupRate: 0 }
  if (selectedOfferingId.value) {
    if (canWriteAttendance.value) await visualApi.resetStream(offeringId)
    if (selectedOfferingId.value !== offeringId) return
    await loadArchivedSessions()
    await restoreSelectedAttendance()
  }
  await fetchDashboardData()
}

const fetchDashboardData = async () => {
  if (!selectedOfferingId.value) {
    overview.value = {
      totalRegistered: 0,
      currentPresent: 0,
      currentAbsent: 0,
      attendanceRate: 0,
      realtimeLookupRate: 0,
      lookdownCount: 0,
      focusLevel: '待启动',
      auditingCount: 0,
      auditingStudentIds: [],
      lastUpdateTime: ''
    }
    trendData.value = []
    studentsStatus.value = []
    return
  }

  try {
    const offeringId = selectedOfferingId.value
    const [ov, tr, st] = await Promise.all([
      visualApi.getOverview(offeringId),
      visualApi.getTrend(offeringId),
      visualApi.getStudentsStatus(offeringId)
    ])
    if (selectedOfferingId.value !== offeringId) return
    if (isMonitoring.value) {
      const status = await visualApi.getMonitorState()
      if (status.offeringId !== offeringId || !status.running || status.error || status.fatal) {
        monitorError.value = status.error || '摄像头数据连接已停止'
        await stopCamera().catch(() => {})
        await loadOfferings()
      } else { monitorReporting.value = !!status.reporting }
    }
    if (ov) overview.value = ov
    trendData.value = tr || []
    studentsStatus.value = st || []

    if (overview.value.currentPresent > 0 || isMonitoring.value || isSimulating.value) {
      lastActiveMetrics.value = {
        present: overview.value.currentPresent,
        rate: overview.value.attendanceRate,
        lookupRate: overview.value.realtimeLookupRate
      }
    }
  } catch (error) {
    if (isMonitoring.value || isMonitorStarting.value) {
      monitorError.value = error instanceof Error ? error.message : '考勤数据连接已停止'
      await stopCamera().catch(() => {})
      await loadOfferings()
    }
    console.error('拉取大屏态势数据失败', error)
  }
}

const toggleMonitor = async () => {
  if (!canWriteAttendance.value || isMonitorStarting.value || isSimulationStarting.value || isSimulating.value) return
  if (isMonitoring.value) { await stopCamera(); return }
  const offeringId = selectedOfferingId.value
  if (!offeringId) return
  const generation = ++monitorGeneration
  monitorAbort = new AbortController()
  isMonitorStarting.value = true; monitorError.value = ''
  try {
    if (!currentSessionId.value) {
      const session = await attendanceApi.start({ offeringId, weekNumber: 2, classroom: getCurrentClassroom() })
      if (!dashboardActive || generation !== monitorGeneration || selectedOfferingId.value !== offeringId) return
      currentSessionId.value = session.id
    }
    const status = await visualApi.startMonitor(offeringId, currentSessionId.value!, monitorAbort.signal)
    if (!dashboardActive || generation !== monitorGeneration || selectedOfferingId.value !== offeringId) return
    isMonitoring.value = true; monitorReporting.value = !!status.reporting
    cameraSessionId = currentSessionId.value
    videoFeedUrl.value = status.videoUrl || ''
    await fetchDashboardData()
  } catch (error: any) {
    if (generation === monitorGeneration && dashboardActive) {
      monitorError.value = error.message || '摄像头启动失败'
      await visualApi.stopMonitor().catch(() => {})
      isMonitoring.value = false; monitorReporting.value = false
    }
  } finally {
    if (generation === monitorGeneration) isMonitorStarting.value = false
  }
}

const openClassStudentModal = async () => {
  if (!selectedOfferingId.value) return
  try {
    const res = await courseApi.getOfferingStudents(selectedOfferingId.value)
    currentOfferingStudents.value = res.enrolled || []
    availableStudents.value = res.available || []
    selectedStudentsToAdd.value = []
    activeModalTab.value = 'enrolled'
    showStudentModal.value = true
  } catch (e) {
    console.error('获取班级学生名单失败', e)
  }
}

const handleAddStudentsToClass = async () => {
  if (!canManageRoster.value || !selectedOfferingId.value || selectedStudentsToAdd.value.length === 0) return
  try {
    await courseApi.addStudentsToOffering(selectedOfferingId.value, selectedStudentsToAdd.value)
    await openClassStudentModal()
    await loadOfferings()
    await fetchDashboardData()
  } catch (e: any) {
    alert(e.message || '添加学生失败')
  }
}

const handleRemoveStudentFromClass = async (studentId: string, studentName: string) => {
  if (!canManageRoster.value || !selectedOfferingId.value) return
  if (!confirm(`确定将学生 ${studentName} (${studentId}) 移出当前课程班级吗？`)) return
  try {
    await courseApi.removeStudentFromOffering(selectedOfferingId.value, studentId)
    await openClassStudentModal()
    await loadOfferings()
    await fetchDashboardData()
  } catch (e: any) {
    alert(e.message || '移出学生失败')
  }
}

const finishAndArchiveAttendance = async () => {
  if (!canWriteAttendance.value || !selectedOfferingId.value) return

  const useStoredCameraMetrics = currentSessionId.value !== null && cameraSessionId === currentSessionId.value
  let finalPresent = overview.value.currentPresent > 0 ? overview.value.currentPresent : lastActiveMetrics.value.present
  let finalRate = overview.value.attendanceRate > 0 ? overview.value.attendanceRate : lastActiveMetrics.value.rate
  let finalLookup = overview.value.realtimeLookupRate > 0 ? overview.value.realtimeLookupRate : lastActiveMetrics.value.lookupRate
  const finalExpected = overview.value.totalRegistered

  const msg = `【确认下课并归档入库】\n\n您即将对当前班级《${offeringList.value.find(o => o.id === selectedOfferingId.value)?.className}》执行下课归档操作：\n\n• 应到人数：${finalExpected} 人\n• 实到人数：${finalPresent} 人\n• 最终出勤率：${finalRate}%\n• 平均抬头率：${finalLookup}%\n\n确认后，系统将正式关闭本堂推流并原子性持久化至 MySQL 考勤档案表。确定下课吗？`

  if (!confirm(msg)) return

  try {
    // 1. 如果摄像头正在推断，先关闭摄像头
    if (isMonitoring.value) {
      await stopCamera()
    }

    // 2. 如果正在演示模拟流，先停止模拟推流
    if (isSimulating.value && simulationTimer) {
      clearInterval(simulationTimer)
      simulationTimer = null
      isSimulating.value = false
    }

    // 3. 优先通过当前会话 ID 调用 finish 接口原子化归档入库
    if (currentSessionId.value) {
      const finished = await attendanceApi.finish({
        sessionId: currentSessionId.value,
        ...(useStoredCameraMetrics ? {} : { actualCount: finalPresent, avgLookupRate: finalLookup }),
      })
      finalPresent = finished.actualCount; finalRate = finished.attendanceRate; finalLookup = finished.avgLookupRate
      currentSessionId.value = null
      cameraSessionId = null
    } else {
      // 容错：直接创建归档会话
      const created = await attendanceApi.start({
        offeringId: selectedOfferingId.value,
        weekNumber: 2,
        classroom: getCurrentClassroom(),
      })
      if (created?.id) {
        await attendanceApi.finish({
          sessionId: created.id,
          actualCount: finalPresent,
          avgLookupRate: finalLookup,
        })
      }
    }

    // 4. 重置 Redis 运行时大盘推流数据
    if (selectedOfferingId.value) {
      await visualApi.resetStream(selectedOfferingId.value)
    }
    await fetchDashboardData()
    lastActiveMetrics.value = { present: 0, rate: 0, lookupRate: 0 }

    // 5. 重新拉取历史归档列表
    await loadArchivedSessions()

    alert(`【课堂考勤归档成功】\n\n本次课堂已正式下课并永久归档至教务系统历史数据库：\n• 实到人数：${finalPresent} 人\n• 最终出勤率：${finalRate}%\n• 平均抬头率：${finalLookup}%\n\n大屏已自动复位待机；您可点击【考勤归档记录】随时查验历次入库明细！`)
  } catch (e: any) {
    alert('归档失败: ' + (e.message || '未知错误'))
  }
}

const toggleSimulation = async () => {
  if (isSimulating.value) { stopSimulation(); return }
  if (!canWriteAttendance.value || !selectedOfferingId.value || isSimulationStarting.value || isMonitorStarting.value || isMonitoring.value) return
  const offeringId = selectedOfferingId.value
  const generation = ++simulationGeneration
  const stillSelected = () => generation === simulationGeneration && selectedOfferingId.value === offeringId
  isSimulationStarting.value = true
  try {
    if (!currentSessionId.value) {
      const session = await attendanceApi.start({ offeringId, weekNumber: 2, classroom: getCurrentClassroom() })
      if (!stillSelected()) return
      if (!session?.id) throw new Error('未能建立考勤会话')
      currentSessionId.value = session.id
    }
    const roster = await courseApi.getOfferingStudents(offeringId)
    if (!stillSelected()) return
    const enrolledPresent = (roster.enrolled || []).slice(0, 4).map((s: any) => s.studentId)
    const simulatedPresent = [...enrolledPresent, '20249999']
    const offering = selectedOffering.value
    isSimulating.value = true
    let reporting = false
    simulationTimer = window.setInterval(async () => {
      if (!stillSelected() || reporting) return
      reporting = true
      try {
        const detected = simulatedPresent.length
        const lookup = Math.floor(detected * (0.8 + Math.random() * 0.15))
        const poses: Record<string, string> = {}
        simulatedPresent.forEach(id => { poses[id] = Math.random() > 0.25 ? 'UP' : 'DOWN' })
        await visualApi.reportStream({
          sessionId: 'sim-' + currentSessionId.value,
          attendanceSessionId: currentSessionId.value,
          offeringId,
          courseName: offering?.course?.courseName || '',
          className: offering?.className || '',
          detectedPersonCount: detected,
          lookupCount: lookup,
          lookdownCount: detected - lookup,
          lookupRate: lookupRatio(lookup, detected),
          presentStudentIds: simulatedPresent,
          studentPoses: poses
        })
      } catch (error: any) {
        if (stillSelected()) {
          stopSimulation()
          await loadOfferings()
          alert('模拟推流已停止: ' + (error.message || '请检查班级权限和冻结状态'))
        }
      } finally { reporting = false }
    }, 1500)
  } catch (error: any) {
    if (stillSelected()) {
      stopSimulation()
      await loadOfferings()
      alert('启动模拟失败: ' + (error.message || '未知错误'))
    }
  } finally {
    if (generation === simulationGeneration) isSimulationStarting.value = false
  }
}

const onVideoFeedError = () => {
  // 视频流加载中重试
}

const restoreSelectedAttendance = async () => {
  const offeringId = selectedOfferingId.value
  if (!offeringId) return
  try {
    const session = await attendanceApi.getCurrent(offeringId)
    if (selectedOfferingId.value === offeringId && Number(session?.offering?.id) === offeringId) {
      currentSessionId.value = session.id
    }
  } catch (error) { console.error('恢复所选班次考勤会话失败', error) }
}

onMounted(async () => {
  if (!props.loggedInUser) {
    try {
      const me = await authApi.getMe()
      internalUser.value = me
    } catch (e) {
      console.warn('获取当前登录用户失败', e)
    }
  }
  await Promise.all([loadOfferings(), loadSchedules()])
  syncSelectedOffering()
  if (selectedOfferingId.value) {
    await loadArchivedSessions()
    try {
      await restoreSelectedAttendance()
      const status = await visualApi.getMonitorState()
      isMonitoring.value = !!status.running && !!status.reporting && status.offeringId === selectedOfferingId.value
      if (isMonitoring.value) cameraSessionId = status.sessionId || null
      monitorReporting.value = isMonitoring.value
      if (isMonitoring.value) videoFeedUrl.value = status.videoUrl || ''
    } catch (error) { console.error('恢复考勤会话失败', error) }
    
    // 若未开流，主动复位一次 Redis 幽灵残留
    if (!isMonitoring.value && canWriteAttendance.value) {
      try {
        await visualApi.resetStream(selectedOfferingId.value)
      } catch {}
    }
  }

  await fetchDashboardData()
  pollTimer = window.setInterval(fetchDashboardData, 1200)
})

watch(() => props.loggedInUser, (newUser) => {
  if (newUser) {
    internalUser.value = newUser
    syncSelectedOffering()
    onOfferingChange()
  }
})

onUnmounted(() => {
  dashboardActive = false
  if (localStorage.getItem('jwtToken')) void stopCamera().catch(() => {})
  else { monitorGeneration++; monitorAbort?.abort(); isMonitoring.value = false }
  stopSimulation()
  if (pollTimer) clearInterval(pollTimer)
  if (simulationTimer) clearInterval(simulationTimer)
})
</script>
